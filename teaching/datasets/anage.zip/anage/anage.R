library(tidyverse)
anage <- read.delim("data/anage_data.txt")
table(anage$Specimen.origin)

anage_sub = anage |>
    subset(Class %in% c("Aves", "Mammalia"))

ggplot(anage_sub, aes(x = Adult.weight..g., y = Maximum.longevity..yrs., color = Sample.size))+
    geom_point(size = .3) +
    stat_smooth(se = FALSE) +
    facet_wrap(~ Class, scales = "free_x") +
    scale_x_log10() + scale_y_log10()
