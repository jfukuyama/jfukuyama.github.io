README for Analysis of Gwern Zeodata

Contents of this directory:
- Readme file
- Data: gwern-zeodata.csv
- Analysis script: gwern.Rmd

To reproduce our analysis, compile the Rmd gwern.Rmd from the source directory.

You will need to have the ggplot2 package installed.

----------------------------------------

sessionInfo for the R session that ran the original analysis:

> sessionInfo()
R version 4.3.0 (2023-04-21)
Platform: aarch64-apple-darwin20 (64-bit)
Running under: macOS Ventura 13.5

Matrix products: default
BLAS:   /Library/Frameworks/R.framework/Versions/4.3-arm64/Resources/lib/libRblas.0.dylib 
LAPACK: /Library/Frameworks/R.framework/Versions/4.3-arm64/Resources/lib/libRlapack.dylib;  LAPACK version 3.11.0

locale:
[1] en_US.UTF-8/en_US.UTF-8/en_US.UTF-8/C/en_US.UTF-8/en_US.UTF-8

time zone: America/Indiana/Indianapolis
tzcode source: internal

attached base packages:
[1] stats     graphics  grDevices utils     datasets  methods   base     

other attached packages:
[1] reshape2_1.4.4 ggplot2_3.4.4 

loaded via a namespace (and not attached):
 [1] vctrs_0.6.4      cli_3.6.1        rlang_1.1.1      stringi_1.7.12  
 [5] generics_0.1.3   labeling_0.4.3   glue_1.6.2       colorspace_2.1-0
 [9] plyr_1.8.9       scales_1.2.1     fansi_1.0.5      grid_4.3.0      
[13] munsell_0.5.0    tibble_3.2.1     lifecycle_1.0.3  stringr_1.5.0   
[17] compiler_4.3.0   dplyr_1.1.3      Rcpp_1.0.11      pkgconfig_2.0.3 
[21] farver_2.1.1     R6_2.5.1         tidyselect_1.2.0 utf8_1.2.3      
[25] pillar_1.9.0     magrittr_2.0.3   tools_4.3.0      withr_2.5.1     
[29] gtable_0.3.4    
